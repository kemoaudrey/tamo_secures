const BASE_URL = "http://41.216.232.85";

export default BASE_URL;
