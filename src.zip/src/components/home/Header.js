import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

function Header() {
  return (
    <header className="headerr">
      <div className="logo">
        <img src="assets/INQ-logo-12.png" alt="INQ Logo" />
      </div>
      <Link to="/login">
        <button className="login-btn">Login</button>
      </Link>
    </header>
  );
}

export default Header;
