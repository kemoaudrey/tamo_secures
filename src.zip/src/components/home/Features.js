import React, { useEffect } from 'react';
import Aos from 'aos';
import 'aos/dist/aos.css';
import './Home.css';
import { QrCode, Shield, Share2 } from 'lucide-react'

const features = [
  {
    icon: <QrCode className="w-12 h-12 text-red-500" />,
    title: 'Easy QR Code Sharing',
    description: 'Share your contact information instantly with a simple QR code scan.'
  },
  {
    icon: <Shield className="w-12 h-12 text-red-500" />,
    title: 'Secure and Private',
    description: 'Your data is protected with state-of-the-art encryption and privacy controls.'
  },
  {
    icon: <Share2 className="w-12 h-12 text-red-500" />,
    title: 'Seamless Integration',
    description: 'Easily integrate with your existing contact management systems and apps.'
  }
];

function Features() {
  useEffect(() => {
    Aos.init({ duration: 1000 });
  }, []);

  return (
    <section className="features-section">
      <h2>Key Features</h2>
      <div className="features-container">
        {features.map((feature, index) => (
          <div className="feature-card" data-aos="fade-up" data-aos-delay={index * 100} key={index}>
            <div className="icon">{feature.icon}</div>
            <h3>{feature.title}</h3>
            <p>{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Features;
