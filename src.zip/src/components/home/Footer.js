import React from 'react';
import './Home.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>INQ vCard</h3>
          <p>Transforming professional networking with advanced vCard solutions.</p>
        </div>
        {/* <div className="footer-section">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="/">About Us</a></li>
            <li><a href="/">Features</a></li>
            <li><a href="/">Pricing</a></li>
            <li><a href="/">Contact</a></li>
          </ul>
        </div> */}
        {/* <div className="footer-section">
          <h4>Stay Connected</h4>
          <form>
            <input type="email" placeholder="Enter your email" />
            <button type="submit">Subscribe</button>
          </form>
        </div> */}
      </div>
      <div className="footer-bottom">
        &copy; {new Date().getFullYear()} INQ vCard. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;
