
import React, {useEffect} from 'react';

import "../home/Home.css";
import Aos from "aos";
import 'aos/dist/aos.css'
import Footer from './Footer';
import Features from './Features';
import Header from './Header';
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCardImage,
}
from 'mdb-react-ui-kit';

function Home() {
  useEffect(() => {
    Aos.init({ duration: 2000 });
  }, []);
  return (

    <MDBContainer fluid className='p-4 background-radial-gradient overflow-hidden'>
      {/* <header class="headerr">
        <div class="logo">
          <img alt="logo" src="assets/INQ-logo-12.png"/>
        </div>
        <Link to="/login"><button class="login-btn">
          Login
        </button></Link>
     
    </header> */}
    <Header />
      <MDBRow>

        <MDBCol md='6' className='text-center text-md-start d-flex flex-column justify-content-center'>

          <h1 data-aos="fade-up" className="my-5 display-3 fw-bold ls-tight px-3" style={{color: 'hsl(0, 27%, 2%)'}}>
          The Ultimate vCard Solution <br />
            <span style={{color: 'hsl(0, 83%, 79%) '}}>for Your Professional Networking.</span>
          </h1>

          <p data-aos="fade-right" className='px-3' style={{color: ' hsl(0, 3%, 14%)'}}>
          Elevate your networking experience with our advanced vCard application, designed to seamlessly share and manage your contact information. Experience the convenience of digital contact sharing while maintaining privacy and security.
          </p>

        </MDBCol>

        <MDBCol md='6' className='position-relative'>

          <div id="radius-shape-1" className="position-absolute rounded-circle shadow-5-strong"></div>
          <div id="radius-shape-2" className="position-absolute shadow-5-strong"></div>

          <div class="image-content">

            <MDBCardImage src='assets/qr-code-concept-illustration.png' alt="QRcode" className='rounded-start w-100'/>

     </div>

        </MDBCol>

      </MDBRow>
      <Features />
      <Footer />
    </MDBContainer>
  );
}

export default Home;


// import React, { useEffect } from 'react';
// import Aos from 'aos';
// import 'aos/dist/aos.css';
// import Header from '../components/Header';
// import Footer from '../components/Footer';
// import Features from '../components/Features';
// import './Home.css';

// function Home() {
//   useEffect(() => {
//     Aos.init({ duration: 2000 });
//   }, []);

//   return (
//     <div className="home-container">
//       <Header />
//       <div className="main-content">
//         <div className="text-content">
//           <h1 data-aos="fade-up">
//             The Ultimate vCard Solution <br />
//             <span>for Your Professional Networking.</span>
//           </h1>
//           <p data-aos="fade-right">
//             Elevate your networking experience with our advanced vCard application, designed to seamlessly share and manage your contact information. Experience the convenience of digital contact sharing while maintaining privacy and security.
//           </p>
//         </div>
//         <div className="image-container" data-aos="fade-left">
//           <img src="assets/qr-code-concept-illustration.png" alt="QR Code Illustration" />
//         </div>
//       </div>
//       <Features />
//       <Footer />
//     </div>
//   );
// }

// export default Home;
